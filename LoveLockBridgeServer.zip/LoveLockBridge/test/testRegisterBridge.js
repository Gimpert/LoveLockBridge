var should = require('chai').should();
var expect = require('chai').expect;
var supertest = require('supertest');
var api = supertest('http://localhost:3000');
var mongodb = require('mongodb');

var mongoclient = mongodb.MongoClient;
var url = 'mongodb://localhost:27017/llb';

describe('hooks', function(){

	before(function	(){
		mongoclient.connect(url,function(err,db){
			if(err){
				console.log('unable to connect. ',err);
			} else {
				mongo = db;
				//console.log('connection established to ',url);
				bridgeCollection = db.collection('bridges');
			}
		});
	});

	after(function(){
	});

});

describe('Register Bridge', function(){
	it('should return an error for invalid parameters',function(done){
		api.post('/registerBridge')
		.set('Accept', 'application/json')
		.expect(200)
		.end(function(err,res){
			expect(res.body).to.have.property('error');
			expect(res.body.error).to.equal('invalid params');
			done();
		});
	});

	it('should return a list of nearby clients', function(){
		var querystring = '/registerBridge';
		querystring += '?lat=1.0';
		querystring += '&lng=1.0';
		querystring += '&range=50';

		api.post(querystring)
		.set('Accept', 'application/json')
		.unset('If-None-Match')
		.expect(200)
		.end(function(err, res){			
			expect(res.body).to.have.property('nearbyClients');
		});
	});

});