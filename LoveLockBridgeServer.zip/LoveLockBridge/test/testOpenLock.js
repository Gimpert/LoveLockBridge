var should = require('chai').should();
var expect = require('chai').expect;
var supertest = require('supertest');
var api = supertest('http://localhost:3000');

describe('Open Lock', function(){
	it('should return the correct message', function(){
		var querystring = '/openLock';
		querystring += '?lat=10.0';
		querystring += '&lng=10.0';
		querystring += '&id=56eadde0ce93f260099b8d39';
		querystring += '&pswd=zO1ZsGJL';

		api.get(querystring)
		.set('Accept', 'application/json')
		.unset('If-None-Match')
		.expect(200)
		.end(function(err, res){
			expect(res.body).to.have.property('message');
			expect(res.body.error).to.equal('password validate');
		});
	});

	it('should return an error for invalid parameters',function(){
		api.get('/openLock')
		.set('Accept', 'application/json')
		.expect(200)
		.end(function(err,res){
			expect(res.body).to.have.property('error');
			expect(res.body.error).to.equal('invalid params');
		});
	});

	it('should return an error for a lock not in the db',function(){
		var querystring = '/openLock';
		querystring += '?lat=10.0';
		querystring += '&lng=10.0';
		querystring += '&id=NotInDatabase';
		querystring += '&pswd=password';

		api.get(querystring)		
		.set('Accept', 'application/json')
		.expect(200)
		.end(function(err,res){
			expect(res.body).to.have.property('error');
			expect(res.body.error).to.equal('lock not found');
		});
	});

	it('should return an error for an incorrect password', function(){
		var querystring = '/openLock';
		querystring += '?lat=10.0';
		querystring += '&lng=10.0';
		querystring += '&id=56eadde0ce93f260099b8d39';
		querystring += '&pswd=WrongPassword';

		api.get(querystring)
		.set('Accept', 'application/json')
		.unset('If-None-Match')
		.expect(200)
		.end(function(err, res){			
			expect(res.body).to.have.property('error');
			expect(res.body.error).to.equal('invalid password');
		});
	});

	it('should return an error for no bridge in range', function(){
		var querystring = '/openLock';
		querystring += '?lat=25.0';
		querystring += '&lng=25.0';
		querystring += '&id=56eadde0ce93f260099b8d39';
		querystring += '&pswd=zO1ZsGJL';

		api.get(querystring)
		.set('Accept', 'application/json')
		.unset('If-None-Match')
		.expect(200)
		.end(function(err, res){			
			expect(res.body).to.have.property('error');
			expect(res.body.error).to.equal('no bridge in range');
		});
	});


});