var should = require('chai').should();
var expect = require('chai').expect;
var supertest = require('supertest');
var api = supertest('http://localhost:3000');

describe('In Range of bridge', function(){
	it('should return true', function(){
		var querystring = '/inRangeOfBridge';
		querystring += '?lat=10.0';
		querystring += '&lng=10.0';

		api.get(querystring)
		.set('Accept', 'application/json')
		.unset('If-None-Match')
		.expect(200)
		.end(function(err, res){
			expect(res.text).to.equal('true');
		});
	});

	it('should return false',function(){
		var querystring = '/inRangeOfBridge'
		querystring += '?lat=25.0';
		querystring += '&lng=25.0';

		api.get(querystring)
		.set('Accept', 'application/json')
		.expect(200)
		.end(function(err,res){
			expect(res.text).to.equal('false');
		});
	});

});