var should = require('chai').should();
var expect = require('chai').expect;
var supertest = require('supertest');
var api = supertest('http://localhost:3000');
var mongodb = require('mongodb');

var mongoclient = mongodb.MongoClient;
var url = 'mongodb://localhost:27017/llb';

describe('hooks', function(){

	before(function	(){
		mongoclient.connect(url,function(err,db){
			if(err){
				console.log('unable to connect. ',err);
			} else {
				mongo = db;
				//console.log('connection established to ',url);
				lockCollection = db.collection('locks');
			}
		});
	});

	after(function(){
		lockCollection.remove({name:'testAddLock'});
	});

});

describe('Add Lock', function(){
	it('should return an error for invalid parameters',function(done){
		api.post('/addLock')
		.set('Accept', 'application/json')
		.expect(200)
		.end(function(err,res){
			expect(res.body).to.have.property('error');
			expect(res.body.error).to.equal('invalid params');
			done();
		});
	});

	it('should return an error for no bridge in range', function(){
		var querystring = '/addLock';
		querystring += '?lat=25.0';
		querystring += '&lng=25.0';
		querystring += '&name=testAddLock';
		querystring += '&message=Testing add lock endpoint';

		api.post(querystring)
		.set('Accept', 'application/json')
		.unset('If-None-Match')
		.expect(200)
		.end(function(err, res){			
			expect(res.body).to.have.property('error');
			expect(res.body.error).to.equal('no bridge in range');
		});
	});

	it('should return the info for the added lock', function(){
		var querystring = '/addLock';
		querystring += '?lat=10.0';
		querystring += '&lng=10.0';
		querystring += '&name=testAddLock';
		querystring += '&message=Testing add lock endpoint';

		api.post(querystring)
		.set('Accept', 'application/json')
		.unset('If-None-Match')
		.expect(200)
		.end(function(err, res){			
			expect(res.body).to.have.property('id');
			expect(res.body).to.have.property('lockName');
			expect(res.body.lockName).to.equal('testAddLock');
			expect(res.body).to.have.property('password');
		});
	});
});