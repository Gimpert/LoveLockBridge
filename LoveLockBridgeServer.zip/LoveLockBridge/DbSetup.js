var db = connect('localhost:27017/llb');
db.createCollection('locks');
db.createCollection('bridges');
db.createCollection('lockClients');

db.bridges.createIndex({"createdAt" : 1}, {"expireAfterSeconds" : 10});
db.lockClients.createIndex({"createdAt" : 1}, {"expireAfterSeconds" : 10});
