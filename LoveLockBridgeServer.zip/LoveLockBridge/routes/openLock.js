var express = require('express');
var loopback = require('loopback');
var rangeHelper = require('../helpers/rangehelper');

var database = require('../helpers/database');
var mongodb = require('mongodb');
var ObjectId = mongodb.ObjectId;

var router = express.Router();

database(function(err, db){
	lockCollection = db.collection('locks');
	bridgeCollection = db.collection('bridges');
});


router.get('/',function(req,res){
	//Get values from HTTP GET request
	var latitude = Number(req.query.lat);
	var longitude = Number(req.query.lng);
	var lockId = req.query.id;
	var password = req.query.pswd;

	//Check parameter values exist
	if(!(lockId && latitude && longitude && password)){
		res.json({'error': 'invalid params'});
		console.log('invalid params');
		return;
	}
	var id = new ObjectId(lockId);
	var location = new loopback.GeoPoint({lat: latitude, lng: longitude});

	rangeHelper.inRangeOfBridge(bridgeCollection, location, function(err, inRange){
		if(err) throw err;
		if(inRange){
			lockCollection.findOne({ _id: id}, function(err,lock){
				if(err) throw err;
				if(lock == null){
					res.json({"error":"lock not found"});
				} else if (lock.password && (password != lock.password)) {
					console.log(password);
					console.log(lock.password);
					res.json({'error':'invalid password'});
				} else {
					console.log('valid password, sending message');

					//res.json({'message':lock.message});
					res.json({'message' : lock.message});
				}
			});			
		} else {
			res.json({'error':'no bridge in range'});
		}		
	});

});

module.exports = router;