var express = require('express');
var loopback = require('loopback');
var randomstring = require('randomstring');
var helper = require('../helpers/rangehelper');

var mongodb = require('mongodb');
var ObjectId = mongodb.ObjectId;

var nodemailer = require('nodemailer');
var xoauth2 = require('xoauth2');

var router = express.Router();

var collection = null;

var mongo = null;

var mongoclient = mongodb.MongoClient;
var url = 'mongodb://localhost:27017/llb';
mongoclient.connect(url,function(err,db){
	if(err){
		console.log('unable to connect. ',err);
	} else {
		mongo = db;
		//console.log('connection established to ',url);
		lockCollection = db.collection('locks');
	}
});

var generator = xoauth2.createXOAuth2Generator({
    user: '{lovelockbridgencsu@gmail}',
    clientId: '{200160440999-ar9i91ofon3mvaetnt6tsvop5v0gfdbn.apps.googleusercontent.com}',
    clientSecret: '{ehzDQrVCNSJ9sEV9143HHXoA}',
    refreshToken: '{refresh-token}',
    accessToken: '{cached access token}'
});

var transporter = nodemailer.createTransport({
    service: 'gmail',
    auth: {
        xoauth2: generator
    }
});

transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: 'lovelockbridgencsu@gmail.com',
    pass: 'Infusion11'
  }
});

// listen for token updates (if refreshToken is set)
// you probably want to store these to a db
generator.on('token', function(token){
    console.log('New token for %s: %s', token.user, token.accessToken);
});

router.get('/',function(req,res){
	//Get values from HTTP GET request
	var destEmailAddr = req.query.targetEmail;
	var lockId = req.query.id;
	var password = req.query.pswd;
	var recipientName = req.query.targetName;
	var senderName = req.query.senderName;
	var senderMessage = req.query.senderMessage;

	//Check parameter values exist
	if(!(lockId && password && destEmailAddr && recipientName && senderName && senderMessage)){
		res.json({'error': 'Invalid params'});
		return;
	}

	var id = new ObjectId(lockId);
	lockCollection.findOne({ _id: id}, function(err,lock){
		if(err) throw err;
		if(lock == null){
			res.json({"error":"lock not found"});	
			return;		
		} else if (lock.password && (password != lock.password)) {
			console.log(password);
			console.log(lock.password);
			res.json({'error':'invalid password'});
			return;
		} else {

			///change password
			var newPswd = randomstring.generate(8);
			lockCollection.updateOne(
				{_id:id}, 
				{ $set: {password:newPswd}},
				function(err, result){
					//console.log(result);
					if(err) throw err;
				}
			)

			var textMessage = 'Hello ' + recipientName + ',\n\n You have been sent a key through the Love Lock Bridge system by ' + senderName + '. Copy and paste the following string into the application \n\n' + lock.name + ':' + lockId + ':' + newPswd + '\n\nGo to a bridge to unlock the message! 🐴\n\n ' + senderMessage;
			var htmlMessage = '<p>Hello ' + recipientName + ',</p> <p>You have been sent a key through the Love Lock Bridge system by ' + senderName + '. Copy and paste the following string into the application</p><p>' + lock.name + ':' + lockId + ':' + newPswd + '</p><p>Go to a bridge to unlock the message! 🐴</p><p>'+ senderMessage +'</p>';

			///send email to target
			// setup e-mail data with unicode symbols
			var mailOptions = {
	    		from: '"LoveLock Bridge 👥" <lovelockbridgencsu@gmail.com>', // sender address
	    		to: destEmailAddr, // person receiving the key.
	    		subject: 'Love Lock Bridge Key! ✔', // Subject line        change when it works	
	    		text: textMessage,
	    		html: htmlMessage // html body change when it works
			};
			// send mail with defined transport object
			transporter.sendMail(mailOptions, function(error, info){
	    		if(error){
	    			res.json({'result':error});
	        		return console.log(error);
	    		} else {
	    			console.log('Message sent: ' + info.response);
	    			res.json({'result':'message sent'});
	    		}
			});

			///account info
			///lovelockbridgencsu@gmail.com
			///Infusion11		
		}


	});	
	
});

/* The Mailing code added
var nodemailer = require('nodemailer');
var xoauth2 = require('xoauth2');

// listen for token updates (if refreshToken is set)
// you probably want to store these to a db
generator.on('token', function(token){
    console.log('New token for %s: %s', token.user, token.accessToken);
});

var transporter = nodemailer.createTransport({
    service: 'gmail',
    auth: {
        xoauth2: xoauth2.createXOAuth2Generator({
            user: '{lovelockbridgencsu@gmail}',
            clientId: '{200160440999-ar9i91ofon3mvaetnt6tsvop5v0gfdbn.apps.googleusercontent.com}',
            clientSecret: '{ehzDQrVCNSJ9sEV9143HHXoA}',
            refreshToken: '{refresh-token}',
            accessToken: '{cached access token}'
        })
    }
});

// setup e-mail data with unicode symbols
var mailOptions = {
    from: '"LoveLock Bridge 👥" <lovelockbridgencsu@gmail.com>', // sender address
    to: receiver // person receiving the key.
    subject: 'Hello ✔', // Subject line
    text: 'Hello world 🐴', // plaintext body
    html: '<b>Hello world 🐴</b>' // html body
};

// send mail with defined transport object
transporter.sendMail(mailOptions, function(error, info){
    if(error){
        return console.log(error);
    }
    console.log('Message sent: ' + info.response);
});
*/








module.exports = router;