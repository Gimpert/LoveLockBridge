var express = require('express');
var loopback = require('loopback');
var jwt = require('jsonwebtoken');

var mongodb = require('mongodb');
var ObjectId = mongodb.ObjectId;

var router = express.Router();

var database = require('../helpers/database');
database(function(err, db){
  tokenCollection = db.collection('token');
});


//route middleware to verify a token
router.use(function(req,res, next) {

  // check header or url parameters or post parameters for token
  var token = req.body.token || req.query.token || req.headers['x-access-token'];

  // decode token
  if (token) {

    // verifies secret and checks exp
    jwt.verify(token, app.get('superSecret'), function(err, decoded) {      
      if (err) {
        return res.json({ success: false, message: 'Failed to authenticate token.' });    
      } else {
        // if everything is good, save to request for use in other routes
        req.decoded = decoded;    
        next();
      }
    });

  } else {

    // if there is no token
    // return an error
    return res.status(403).send({ 
        success: false, 
    });
    
  }
});

module.exports = router;