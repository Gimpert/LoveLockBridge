var express = require('express');
var loopback = require('loopback');
var jwt = require('jsonwebtoken');

var mongodb = require('mongodb');
var ObjectId = mongodb.ObjectId;

var router = express.Router();

var collection = null;

var database = require('../helpers/database');
database(function(err, db){
  tokenCollection = db.collection('token');
});


//authenticate a user
router.post('/authenticate',function(req,res){
  
  var token = jwt.sign('llb', app.get('superSecret'))
  expiresInMinutes: 1440

  res.json({
    succes: true,
    token: token
  });
});
