var express = require('express');
var loopback = require('loopback');
var helper = require('../helpers/rangehelper');

var router = express.Router();

var maxRange = 100;

var mongodb = require('mongodb');
var database = require('../helpers/database');

var mongo = null;
database(function(err, db){
	mongo = db;
});

router.post('/',function(req,res){
	//console.log(req.body);
	//var name = req.body.name;
	var latitude = Number(req.body.lat);
	var longitude = Number(req.body.lng);
	var range = Number(req.body.range);

	if(latitude && longitude && range && (range < maxRange)){
		var location = new loopback.GeoPoint({lat: latitude, lng: longitude});

		var bridgeObj = {'loc':location, 'range':range, 'createdAt':new Date()};
		console.log(bridgeObj);
		//Insert document
		mongo.collection('bridges', function(err, collection){
			collection.ensureIndex({loc: "2d"}, function(err, result) {
				if(err) throw err;
				collection.insert(bridgeObj,function(err,doc){
					if(err) throw err;
				});
			});
		});


		mongo.collection('lockClients', function(err, lockClientCollection){
			if (err) throw err;
			helper.locksNearBridge(lockClientCollection, bridgeObj, function(err, clientArray){
				res.json({'nearbyClients':clientArray});
				return;
			});
		});



	} else {
		console.log("invalid params");
		res.json({'error': 'invalid params'});
		return;
	}
});

module.exports = router;