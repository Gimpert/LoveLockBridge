var express = require('express');
var loopback = require('loopback');
var helper = require('../helpers/rangehelper');

var mongodb = require('mongodb');
var ObjectId = mongodb.ObjectId;

var router = express.Router();

var database = require('../helpers/database');
database(function(err, db){
	bridgeCollection = db.collection('bridges');
	lockClientCollection = db.collection('lockClients');
});


router.get('/',function(req,res){
	var curTime = new Date();
	console.log(curTime);
	//Get values from HTTP GET request
	var latitude = Number(req.query.lat);
	var longitude = Number(req.query.lng);
	//Check parameter values exist
	if(!(latitude && longitude)){
		res.json({'error': 'Invalid params'});
		return;
	}

	var location = new loopback.GeoPoint({lat: latitude, lng: longitude});
	var insertObj = {'createdAt':curTime,'loc':location};

	lockClientCollection.insert(insertObj,function(err,doc){
		console.log("client inserted");
		if(err) throw err;
	});
	//Insert document

	helper.inRangeOfBridge(bridgeCollection, location, function(err, result){
		res.send(result);
	});

});

module.exports = router;