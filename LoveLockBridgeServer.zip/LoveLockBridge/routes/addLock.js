var express = require('express');
var loopback = require('loopback');
var helper = require('../helpers/rangehelper');
var randomstring = require('randomstring');

var mongodb = require('mongodb');
var ObjectId = mongodb.ObjectId;

var router = express.Router();
var database = require('../helpers/database');
database(function(err, db){
	lockCollection = db.collection('locks');
});

router.post('/',function(req,res){
	//console.log(req.body);
	var latitude = Number(req.body.lat);
	var longitude = Number(req.body.lng);
	var lockName = req.body.name;
	var lockMessage = req.body.message;

	//Check parameter values exist
	if(!(lockName && latitude && longitude && lockMessage)){
		console.log('invalid params');
		res.json({'error': 'invalid params'});
		return;
	}

	var location = new loopback.GeoPoint({lat: latitude, lng: longitude});

	helper.inRangeOfBridge(bridgeCollection, location, function(err, inRange){
		if(inRange){
			var pswd = randomstring.generate(8);
			var insertObj = {'name':lockName,'message':lockMessage,'password':pswd};
			lockCollection.insert(insertObj,function(err,doc){
				if(err) throw err;
				var response = {id: insertObj._id, name: lockName, password:pswd};
				//console.log(response);
				res.json(response);
			});		
		} else {
			res.json({'error':'no bridge in range'});
		}
	});
	


});

module.exports = router;