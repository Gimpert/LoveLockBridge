var loopback = require('loopback');

module.exports.inRangeOfBridge = function(bridgeCollection, clientLocation, callback){
	var inRange = false;
	bridgeCollection.ensureIndex({loc: "2d"}, function(err, result) {
		if(err) throw err;
		bridgeCollection.find({loc: {$near: [clientLocation.lat, clientLocation.lng], $maxDistance:.01}}).toArray(function(err,bridges){
			//console.log(bridges);
			if(bridges.length > 0){
				inRange = bridges.some(function(bridge, index, array){
					if(bridge != null){
						var dist = loopback.GeoPoint.distanceBetween(clientLocation, bridge.loc, {type:'meters'});
						if(dist < bridge.range){
							return true;
						} else {
							return false
						}
					}		
				});
			}
			callback(null, inRange);
		});
	});
}

module.exports.locksNearBridge = function(clientCollection, bridge, callback){
	var inRangeClients = [];
	if(clientCollection){
		clientCollection.find().toArray(function(err, clients){
			console.log(clients);
			clients.forEach(function(client){
				var dist = loopback.GeoPoint.distanceBetween(bridge.loc, client.loc, {type:'meters'});
				if(dist < bridge.range){
					inRangeClients.push(client);
				}
			});
			callback(null, inRangeClients);
		});
	}
}
