var mongodb = require('mongodb');

var Database = function(){};
var dbInstance = null;

var GetDb = function(callback){
	if(dbInstance){
		console.log('db exists');
		callback(null, dbInstance);
		return;
	} 
	mongodb.MongoClient.connect('mongodb://localhost:27017/llb', function(err,database){
		if(err){
			console.log('unable to connect. ',err);
			callback(err, null);
		} else {
			callback(null, database);
			return;
		}
	});
}

module.exports = GetDb;